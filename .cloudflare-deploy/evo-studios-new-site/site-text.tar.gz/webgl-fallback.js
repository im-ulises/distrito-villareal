/* Preserve the reference's THREE scene, projection, layout, curvature and drag.
   Use the GPU renderer normally; project the same textured planes into Canvas2D
   on preview devices where WebGL is unavailable. */
window.gianCreateGalleryRenderer = function(THREE) {
  function ProjectedGalleryRenderer() {
    this.domElement = document.createElement('canvas');
    this.domElement.setAttribute('aria-label','Draggable studio image gallery');
    this.domElement.dataset.renderer = 'canvas-fallback';
    this.capabilities = {getMaxAnisotropy:()=>1};
    this.width = 1; this.height = 1; this.ratio = 1;
    this.context = this.domElement.getContext('2d',{alpha:true});
  }
  ProjectedGalleryRenderer.prototype.setSize = function(w,h) {
    this.width = w; this.height = h;
    this.domElement.width = Math.round(w*this.ratio);
    this.domElement.height = Math.round(h*this.ratio);
    this.domElement.style.width = w+'px';
    this.domElement.style.height = h+'px';
  };
  ProjectedGalleryRenderer.prototype.setPixelRatio = function(ratio) {
    this.ratio = Math.min(ratio||1,2); this.setSize(this.width,this.height);
  };
  ProjectedGalleryRenderer.prototype.render = function(scene,camera) {
    const ctx=this.context, w=this.width, h=this.height;
    if (!ctx) return;
    ctx.setTransform(this.ratio,0,0,this.ratio,0,0);ctx.clearRect(0,0,w,h);
    scene.updateMatrixWorld(); camera.updateMatrixWorld();
    const vp=new THREE.Matrix4().multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse);
    const meshes=[];scene.traverse(mesh=>{if(mesh.isMesh&&mesh.material?.map?.image)meshes.push(mesh);});
    meshes.sort((a,b)=>a.position.z-b.position.z);
    meshes.forEach(mesh=>{
      const image=mesh.material.map.image, geometry=mesh.geometry;
      const position=geometry.attributes.position,uv=geometry.attributes.uv;
      const matrix=new THREE.Matrix4().multiplyMatrices(vp,mesh.matrixWorld);
      const points=[];
      for(let i=0;i<position.count;i++){
        const point=new THREE.Vector3().fromBufferAttribute(position,i).applyMatrix4(matrix);
        points.push({x:(point.x+1)*w/2,y:(1-point.y)*h/2,s:uv.getX(i)*image.width,t:(1-uv.getY(i))*image.height});
      }
      if(points.every(p=>p.x<0)||points.every(p=>p.x>w)||points.every(p=>p.y<0)||points.every(p=>p.y>h))return;
      const indices=geometry.index.array;
      for(let i=0;i<indices.length;i+=3)drawTriangle(image,points[indices[i]],points[indices[i+1]],points[indices[i+2]],mesh.material.opacity);
    });
    function drawTriangle(image,p,q,r,alpha){
      const denominator=p.s*(q.t-r.t)+q.s*(r.t-p.t)+r.s*(p.t-q.t);
      if(!denominator)return;
      const a=(p.x*(q.t-r.t)+q.x*(r.t-p.t)+r.x*(p.t-q.t))/denominator;
      const c=(p.x*(r.s-q.s)+q.x*(p.s-r.s)+r.x*(q.s-p.s))/denominator;
      const e=(p.x*(q.s*r.t-r.s*q.t)+q.x*(r.s*p.t-p.s*r.t)+r.x*(p.s*q.t-q.s*p.t))/denominator;
      const b=(p.y*(q.t-r.t)+q.y*(r.t-p.t)+r.y*(p.t-q.t))/denominator;
      const d=(p.y*(r.s-q.s)+q.y*(p.s-r.s)+r.y*(q.s-p.s))/denominator;
      const f=(p.y*(q.s*r.t-r.s*q.t)+q.y*(r.s*p.t-p.s*r.t)+r.y*(p.s*q.t-q.s*p.t))/denominator;
      ctx.save();ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.lineTo(r.x,r.y);ctx.closePath();ctx.clip();
      ctx.globalAlpha=alpha??1;ctx.transform(a,b,c,d,e,f);ctx.drawImage(image,0,0);ctx.restore();
    }
  };
  try { return new THREE.WebGLRenderer({antialias:true, alpha:true}); }
  catch (_) { return new ProjectedGalleryRenderer(); }
};
