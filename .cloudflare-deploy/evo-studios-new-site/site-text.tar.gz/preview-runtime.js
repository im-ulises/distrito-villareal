/* Static preview compatibility. Original visual and motion scripts are retained. */
(() => {
  'use strict';
  document.querySelectorAll('video').forEach(video => {
    video.muted = true;
    video.playsInline = true;
    video.setAttribute('playsinline', '');
  });
  // Never submit remote forms from a static preview.
  document.addEventListener('submit', event => {
    if (!event.target.matches('[data-preview-form]')) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    let status = event.target.querySelector('[role="status"]');
    if (!status) {
      status = document.createElement('p');
      status.setAttribute('role', 'status');
      event.target.append(status);
    }
    status.textContent = 'Preview only — your message has not been sent.';
  }, true);
})();
